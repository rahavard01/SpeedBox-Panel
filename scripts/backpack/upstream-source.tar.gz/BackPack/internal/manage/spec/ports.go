package spec

import (
	"fmt"
	"net"
	"strconv"
	"strings"

	"github.com/BurntSushi/toml"
	"github.com/backpack/backpack/config"
)

// ValidPort reports whether s is a valid TCP/UDP port number.
func ValidPort(s string) bool {
	n, err := strconv.Atoi(s)
	return err == nil && n >= 1 && n <= 65535
}

// ParsePorts splits a comma-separated port specification into individual
// entries, trimming whitespace and dropping empties. Mapping forms such as
// "443=1.1.1.1:443", ranges "443-450", and plain "443" are all passed through
// to the engine's port parser unchanged.
func ParsePorts(raw string) []string {
	var out []string
	for _, part := range strings.Split(raw, ",") {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		out = append(out, part)
	}
	return out
}

// ValidPortSpec reports whether one forwarded-port entry is in a shape the
// engine's port parser accepts: "N", "N-M", "N=addr", "N-M=addr" or
// "ip:port=addr". The engine reports and ignores an entry it cannot read now
// rather than exiting on it, so a bad one no longer takes the tunnel with it —
// but a mapping that is silently doing nothing is still worth refusing here,
// where the operator is looking at it and can fix it.
func ValidPortSpec(spec string) bool {
	spec = strings.TrimSpace(spec)
	parts := strings.SplitN(spec, "=", 2)
	local := strings.TrimSpace(parts[0])
	if local == "" {
		return false
	}
	if len(parts) == 2 && strings.TrimSpace(parts[1]) == "" {
		return false // "443=" — empty destination
	}
	// "ip:port=addr" — a full local address is only valid in mapping form.
	if h, p, err := net.SplitHostPort(local); err == nil && h != "" {
		return len(parts) == 2 && ValidPort(p)
	}
	// Port range "N-M".
	if strings.Contains(local, "-") {
		r := strings.Split(local, "-")
		if len(r) != 2 {
			return false
		}
		lo, hi := strings.TrimSpace(r[0]), strings.TrimSpace(r[1])
		if !ValidPort(lo) || !ValidPort(hi) {
			return false
		}
		a, _ := strconv.Atoi(lo)
		b, _ := strconv.Atoi(hi)
		return b >= a
	}
	// Plain single port.
	return ValidPort(local)
}

// ValidatePortSpecs checks every forwarded-port entry, returning a descriptive
// error for the first invalid one.
func ValidatePortSpecs(ports []string) error {
	for _, p := range ports {
		if !ValidPortSpec(p) {
			return fmt.Errorf("invalid port entry %q — use forms like 443, 400-450, 443=1.1.1.1:443", strings.TrimSpace(p))
		}
	}
	return nil
}

// Unparsable opens the one problem ValidateConfigFile reports for a file that
// does not parse, which is then the only problem it reports.
const Unparsable = "the file does not parse"

// ValidateConfigFile reports what is wrong with a tunnel configuration on disk,
// without starting anything.
//
// It exists because there was no way to ask. The engine validates thoroughly at
// load — the transport, the carrier's privileges, the proxy settings, the flag
// lists — and it does so by exiting, which is right for a service supervisor and
// useless for a person who has just hand-edited a file and would like to know
// before they restart a tunnel that is currently working. The reload path is
// careful about this in the other direction: a file that does not parse is
// ignored and the tunnel keeps running, quietly, with the operator none the
// wiser that their edit did nothing.
//
// What this covers is deliberately bounded and it says so rather than implying
// more: the file parses, it describes exactly one kind of tunnel, the addresses
// and ports are addresses and ports, and the forwarded-port syntax is the
// syntax. The checks that need the machine — whether a raw socket can be
// opened, whether an interface exists, whether iptables is installed — stay
// where they are, in the engine, because their answers are only true on the
// host the tunnel will run on.
func ValidateConfigFile(path string) []string {
	var problems []string
	add := func(format string, a ...any) { problems = append(problems, fmt.Sprintf(format, a...)) }

	var cfg config.Config
	if _, err := toml.DecodeFile(path, &cfg); err != nil {
		return []string{Unparsable + ": " + err.Error()}
	}

	kinds := 0
	for _, on := range []bool{cfg.Server.BindAddr != "", cfg.Client.RemoteAddr != "",
		cfg.L3.Enabled(), cfg.Direct.Enabled()} {
		if on {
			kinds++
		}
	}
	switch {
	case kinds == 0:
		add("this file describes no tunnel: it has no [server] bind_addr, no [client] " +
			"remote_addr, no [l3] mode and no [direct] mode")
	case kinds > 1:
		add("this file describes %d tunnels at once. One config is one tunnel — the "+
			"engine picks [l3], then [direct], then [server]/[client], and the others "+
			"are silently ignored", kinds)
	}

	if cfg.Server.BindAddr != "" {
		if _, err := ParseTunnelBind(cfg.Server.BindAddr); err != nil {
			add("bind_addr: %v", err)
		}
		if len(cfg.Server.Ports) == 0 {
			add("a server tunnel with no ports forwards nothing")
		}
		if err := ValidatePortSpecs(cfg.Server.Ports); err != nil {
			add("ports: %v", err)
		}
		if strings.TrimSpace(cfg.Server.Token) == "" {
			add("token is empty; both ends must carry the same one")
		}
	}
	if cfg.Client.RemoteAddr != "" {
		if h, p, err := net.SplitHostPort(cfg.Client.RemoteAddr); err != nil {
			add("remote_addr %q is not host:port: %v", cfg.Client.RemoteAddr, err)
		} else if h == "" || !ValidPort(p) {
			add("remote_addr %q has no host, or a port outside 1-65535", cfg.Client.RemoteAddr)
		}
		if strings.TrimSpace(cfg.Client.Token) == "" {
			add("token is empty; both ends must carry the same one")
		}
	}
	if cfg.L3.Enabled() {
		if m := strings.ToLower(strings.TrimSpace(cfg.L3.Mode)); m != "dial" && m != "listen" {
			add("[l3] mode is %q; it has to be \"dial\" or \"listen\"", cfg.L3.Mode)
		}
		if _, _, err := net.SplitHostPort(cfg.L3.Addr); err != nil {
			add("[l3] addr %q is not host:port: %v", cfg.L3.Addr, err)
		}
		if strings.TrimSpace(cfg.L3.Token) == "" {
			add("[l3] token is empty")
		}
		if err := ValidatePortSpecs(cfg.L3.Ports); err != nil {
			add("[l3] ports: %v", err)
		}
	}
	return problems
}
