package health

import (
	"fmt"
	"os/exec"
	"strconv"
	"strings"
	"time"

	"github.com/backpack/backpack/internal/app"
	"github.com/backpack/backpack/internal/manage/core"
	"github.com/backpack/backpack/internal/metrics"
)

// The two questions a tunnel could not answer about itself.
//
// A tunnel that connects and then carries nothing is the hardest failure in
// this system to attribute, because every surface reports health: the service
// is running, the control channel is up, the panel shows it online. Working out
// what was actually wrong meant counting sockets by hand and sampling byte
// counters between two runs of `ss` — an afternoon of it, for a fault that the
// tunnel had all the information to describe in a sentence.
//
// Two things turned out to matter, and neither was visible anywhere:
//
//   - How much of the pool exists. A control channel with no pool behind it
//     looks exactly like a healthy tunnel until somebody tries to use it.
//   - Whether the path can carry a full-sized packet. Where it cannot, and the
//     network declines to say so with an ICMP message, TCP never finds out: the
//     small packets — the handshake, the heartbeats — arrive, so the tunnel
//     comes up and stays up, and every real transfer stalls on the first
//     full-sized segment. Nothing in the tunnel, the kernel or the panel
//     reports this. It has to be measured on purpose.
//
// Both are read-only measurements taken from the live tunnel.

// sockStat is what the kernel knows about one live tunnel connection.
type sockStat struct {
	peer string
	mss  int
	pmtu int
	sent uint64
	recv uint64
}

// tunnelSockets reports the established connections on a tunnel's port, with
// the kernel's view of each. It is the same information `ss -tin` prints,
// parsed rather than eyeballed.
//
// Either endpoint may be the one holding the tunnel port, and which it is
// depends on the role: a server's connections have it locally, a client's have
// it on the far side with an ephemeral port of their own. Matching both is what
// makes this work from either end.
func tunnelSockets(port string) []sockStat {
	out, err := exec.Command("ss", "-tin", "state", "established").Output()
	if err != nil {
		return nil
	}
	return parseSockets(string(out), port)
}

// parseSockets is the parsing half, kept apart from the command so it can be
// tested against real `ss` output. Both mistakes this has already made — taking
// "mss" out of the middle of "rcvmss", and looking only at the local end of the
// connection — were parsing mistakes, and neither was reachable by a test while
// this was welded to exec.
func parseSockets(out, port string) []sockStat {
	var stats []sockStat
	var cur *sockStat
	for _, line := range strings.Split(out, "\n") {
		if line == "" {
			continue
		}
		if line[0] == ' ' || line[0] == '\t' {
			// The indented line carries the kernel's measurements for the
			// connection named on the line before it.
			if cur != nil {
				cur.mss = intField(line, " mss:")
				cur.pmtu = intField(line, " pmtu:")
				cur.sent = uint64(intField(line, " bytes_sent:"))
				cur.recv = uint64(intField(line, " bytes_received:"))
				stats = append(stats, *cur)
				cur = nil
			}
			continue
		}
		f := strings.Fields(line)
		if len(f) < 2 {
			continue
		}
		local, peer := f[len(f)-2], f[len(f)-1]
		if !strings.HasSuffix(local, ":"+port) && !strings.HasSuffix(peer, ":"+port) {
			continue
		}
		host := peer
		if i := strings.LastIndex(peer, ":"); i >= 0 {
			host = peer[:i]
		}
		host = strings.Trim(host, "[]")
		host = strings.TrimPrefix(host, "::ffff:")
		if host == "" || host == "127.0.0.1" || host == "::1" {
			continue
		}
		cur = &sockStat{peer: host}
	}
	return stats
}

// intField pulls a numeric value out of an `ss` info line. The key must include
// its leading space: without it "mss:" also matches inside "rcvmss:" and
// "advmss:", which are different measurements entirely.
func intField(line, key string) int {
	i := strings.Index(line, key)
	if i < 0 {
		return 0
	}
	rest := line[i+len(key):]
	end := 0
	for end < len(rest) && rest[end] >= '0' && rest[end] <= '9' {
		end++
	}
	n, _ := strconv.Atoi(rest[:end])
	return n
}

// probePathMTU finds the largest packet that reaches host, by binary search
// over ICMP with the don't-fragment bit set.
//
// It returns 0 when the question cannot be answered — the path drops ICMP
// entirely, or ping is not installed — which is reported as unknown rather than
// guessed at. Guessing here would be worse than silence: a wrong MTU would have
// the operator clamping a connection that was never the problem.
func probePathMTU(host string) int {
	if host == "" {
		return 0
	}
	if !pingOK(host, 64) {
		return 0 // ICMP does not survive this path at all
	}

	lo, hi, best := 512, 1472, 64
	for lo <= hi {
		mid := (lo + hi) / 2
		if pingOK(host, mid) {
			best = mid
			lo = mid + 1
		} else {
			hi = mid - 1
		}
	}
	return best + 28 // IP header + ICMP header
}

func pingOK(host string, payload int) bool {
	cmd := exec.Command("ping", "-c", "1", "-W", "2", "-M", "do", "-s", strconv.Itoa(payload), host)
	return cmd.Run() == nil
}

// safeMSS is the largest TCP payload that fits inside mtu.
//
// It subtracts a full 40 bytes of headers plus 12 for the timestamps option,
// which Linux enables by default. The textbook figure of mtu-40 assumes a
// bare 20-byte TCP header and produces segments 12 bytes too large on exactly
// the paths where 12 bytes is the difference.
//
// This is the value to *set*. It is deliberately not the value to *test*
// against — see oversizeMSS.
func safeMSS(mtu int) int { return mtu - 20 - 32 }

// oversizeMSS is the segment size above which packets genuinely cannot fit
// inside mtu.
//
// The distinction from safeMSS is the whole of a false alarm that reported
// healthy tunnels as broken. The kernel's snd_mss — what `ss` prints as mss:
// and what this compares — already has the option bytes taken out of it: on a
// 1500-byte path a socket using timestamps reports 1448 and one without them
// reports 1460, and both fit. Testing either against safeMSS, which subtracts
// the options a second time, condemns the second as oversized while it is
// carrying traffic perfectly well.
//
// So detection subtracts only the headers that are always there, and the
// advice keeps its room for options. A clamp is still worth recommending at
// safeMSS, because a clamp is a ceiling that has to hold whether the options
// are in use or not.
func oversizeMSS(mtu int) int { return mtu - 40 }

// minPathMTU is the smallest IPv4 datagram every path is required to carry.
const minPathMTU = 576

// The range an MSS clamp has to fall inside, shared by the check that names a
// value and the setting that applies it.
//
// The floor is derived rather than picked, so that every number pathMTUCheck
// can print is a number SetMSS will accept. Those two drifting apart is the
// worst failure available here: a diagnostic that names the fix and a tunnel
// that then refuses it leaves the operator with nowhere to go, which is how
// this fault wasted an afternoon in the first place.
//
// The ceiling is the textbook maximum for a 1500-byte Ethernet MTU less a bare
// IPv4 and TCP header. A clamp above it can never bind on an ordinary link, so
// accepting one would only ever mean accepting a typo.
var (
	MinMSS = safeMSS(minPathMTU) // 524
	MaxMSS = 1500 - 20 - 20      // 1460
)

// pathMTUCheck turns a measured path MTU and the segment size the tunnel is
// actually sending into the line the operator reads.
//
// It is kept pure and apart from the measurement so the one property that must
// hold — that any clamp it prints is one SetMSS accepts — can be tested across
// the whole range the probe can report, rather than only on the paths someone
// happened to have.
func pathMTUCheck(g string, mtu, negotiated int, fromKernel bool) Check {
	clamp := safeMSS(mtu)
	oversize := negotiated > oversizeMSS(mtu)

	// An ICMP probe that disagrees with a socket carrying traffic is the probe
	// being wrong, not the tunnel.
	//
	// probePathMTU binary-searches with ping and the don't-fragment bit, and on
	// a path that filters or rate-limits large ICMP — which is ordinary on the
	// routes this project exists for — the search bottoms out far below what
	// the path really carries. The old check took that figure as fact and
	// declared a working tunnel broken, on every run, no matter what the
	// tunnel's own MTU was set to. The sockets are the better witness: they are
	// moving bytes at this size right now.
	if oversize && !fromKernel {
		return Check{Group: g, Name: "Path MTU", Level: CheckWarn,
			Detail: fmt.Sprintf("the ICMP probe reached only %d bytes, but the tunnel's sockets are sending segments of %d — this path filters large pings, so the probe is understating it",
				mtu, negotiated),
			Fix: fmt.Sprintf("nothing, unless transfers actually stall — if they do, set the MSS clamp to %d on both ends", clamp)}
	}

	switch {
	case oversize && clamp < MinMSS:
		// Below what IPv4 guarantees every route carries. No clamp rescues
		// this: the value it would need is one no TCP stack is obliged to
		// accept, and the tunnel would crawl even if both ends took it. Saying
		// so beats printing a number the tunnel will refuse.
		return Check{Group: g, Name: "Path MTU", Level: CheckFail,
			Detail: fmt.Sprintf("path carries only %d bytes, below the %d every IPv4 route must — too small to tunnel over", mtu, minPathMTU),
			Fix:    "this is a fault in the route rather than in the tunnel — look for a broken tunnel or VPN in front of it"}

	case oversize:
		// The measured limit is below what the sockets are already sending.
		// Nothing reports this on its own: the oversized segments are dropped
		// without an ICMP reply, so the kernel keeps sending them and the
		// tunnel keeps looking healthy while every real transfer stalls.
		return Check{Group: g, Name: "Path MTU", Level: CheckFail,
			Detail: fmt.Sprintf("path carries %d bytes but the tunnel sends segments of %d — larger packets are being dropped silently", mtu, negotiated),
			Fix:    fmt.Sprintf("set the MSS clamp to %d on both ends — Edit → TCP MSS clamp, or Fine Tune in the panel", clamp)}

	case mtu < 1500:
		return Check{Group: g, Name: "Path MTU", Level: CheckOK,
			Detail: fmt.Sprintf("%d (below 1500, and the tunnel is already inside it at mss %d)", mtu, negotiated)}

	default:
		return Check{Group: g, Name: "Path MTU", Level: CheckOK,
			Detail: fmt.Sprintf("%d, full-sized packets get through", mtu)}
	}
}

// Managed carriers use loopback control/SOCKS connections at ports that do not
// identify the outer HTTPS connection. Counting ss entries at t.Addr reports a
// false empty pool, and measuring that loopback path says nothing about its MTU.
func managedPathChecks(g string, t core.Tunnel) []Check {
	snap, err := metrics.Read(app.ConfigDir, t.Name)
	var pool *metrics.PoolStats
	if err == nil && time.Since(snap.Taken) <= time.Minute {
		pool = snap.Pool
	}
	return []Check{
		managedPoolCheck(g, pool),
		{Group: g, Name: "Path MTU", Level: CheckInfo,
			Detail: "managed HTTPS path; the inner loopback MTU does not describe the carrier",
			Fix:    "verify large transfers through the forwarded entry port"},
	}
}

func managedPoolCheck(g string, pool *metrics.PoolStats) Check {
	c := Check{Group: g, Name: "Pool", Level: CheckInfo,
		Detail: "managed carrier; no recent engine pool snapshot is available on this side",
		Fix:    "check the client engine's pool metrics and verified traffic through the forwarded entry port"}
	if pool == nil {
		return c
	}
	c.Detail = fmt.Sprintf("engine reports %d live pool connections (target %d, configured %d)", pool.Live, pool.Target, pool.Configured)
	c.Level = CheckOK
	c.Fix = ""
	if pool.Live == 0 {
		c.Level = CheckWarn
		c.Fix = "the latest client snapshot has no pool; check its helper and tunnel logs"
	}
	return c
}

// pathChecks measures the ordinary transport's pool and outer path MTU.
func pathChecks(g string, t core.Tunnel) []Check {
	var out []Check

	port := addrPort(t.Addr)
	if port == "" {
		return out
	}
	if isDatagram(t.Transport) {
		// A datagram tunnel has no entry in the TCP socket table, so the pool
		// and the traffic cannot be read the way they are below.
		//
		// The path MTU still can, and it is the one that matters most: a
		// tunnel whose path cannot carry a full-sized packet comes up, answers
		// every health check, carries ping and SSH, and stalls every large
		// transfer — with nothing coming back to say so. Leaving the whole
		// group out meant the transports most likely to be chosen for a hostile
		// path were the ones told least about it.
		return append(out, datagramPathChecks(g, t)...)
	}

	before := tunnelSockets(port)
	if len(before) == 0 {
		out = append(out, Check{Group: g, Name: "Pool", Level: CheckFail,
			Detail: "no established tunnel connections",
			Fix:    "the peer is not connected — check the other side's log and that both hold the same token"})
		return out
	}

	// A control channel on its own is not a working tunnel: the pool is what
	// carries the traffic, and a tunnel with one connection and no pool looks
	// healthy from every other angle while forwarding nothing.
	peer := before[0].peer
	if len(before) == 1 {
		out = append(out, Check{Group: g, Name: "Pool", Level: CheckWarn,
			Detail: "control channel only, no pool connections",
			Fix:    "the client is not maintaining a pool — check its log for dial failures"})
	} else {
		out = append(out, Check{Group: g, Name: "Pool", Level: CheckOK,
			Detail: fmt.Sprintf("%d connections with %s", len(before), peer)})
	}

	// What is actually crossing, right now. Reported rather than judged: an
	// idle tunnel legitimately carries nothing, and calling that a fault would
	// cry wolf on every quiet tunnel.
	time.Sleep(1500 * time.Millisecond)
	var sent, recv uint64
	for _, s := range tunnelSockets(port) {
		sent += s.sent
		recv += s.recv
	}
	var was uint64
	var wasRecv uint64
	for _, s := range before {
		was += s.sent
		wasRecv += s.recv
	}
	out = append(out, Check{Group: g, Name: "Traffic", Level: CheckInfo,
		Detail: fmt.Sprintf("%s out, %s in over 1.5s",
			humanSize(int(saturatingSub(sent, was))), humanSize(int(saturatingSub(recv, wasRecv))))})

	// And the question that costs the most to answer by hand.
	//
	// The kernel is asked first. It has been running PMTU discovery on these
	// very connections and prints the answer in `ss` as pmtu:, which was being
	// parsed and then thrown away while a ping probe re-derived it less
	// reliably. Where both have an answer the kernel's is the one to trust.
	mtu, fromKernel := pathMTU(before, peer)
	if mtu == 0 {
		out = append(out, Check{Group: g, Name: "Path MTU", Level: CheckInfo,
			Detail: "could not probe — the path drops ICMP"})
		return out
	}

	negotiated := 0
	for _, s := range before {
		if s.mss > negotiated {
			negotiated = s.mss
		}
	}

	return append(out, pathMTUCheck(g, mtu, negotiated, fromKernel))
}

// pathMTU settles which figure the check is judged against, and whether it came
// from the kernel or from the ping probe.
//
// The sockets are asked first because they cannot be fooled by a middlebox that
// drops large ICMP: their number is what the TCP stack learned from carrying
// real traffic to this peer. The probe stays as the fallback for when the
// kernel has not recorded one — a connection too young or too idle to have
// discovered anything.
func pathMTU(sockets []sockStat, peer string) (mtu int, fromKernel bool) {
	best := 0
	for _, s := range sockets {
		if s.pmtu > best {
			best = s.pmtu
		}
	}
	if best > 0 {
		return best, true
	}
	return probePathMTU(peer), false
}

// saturatingSub avoids a wild figure when a connection is replaced between the
// two samples and the counter appears to go backwards.
func saturatingSub(now, then uint64) uint64 {
	if now < then {
		return 0
	}
	return now - then
}

// datagramPathChecks is what can still be measured for a tunnel the socket
// table cannot see.
//
// Only the MTU, and only by probe: there is no kernel PMTU figure to prefer
// here, because there is no TCP connection for the kernel to have learned one
// from. The probe is the same binary search over ICMP the stream path falls
// back to.
func datagramPathChecks(g string, t core.Tunnel) []Check {
	host := peerHostFor(t)
	if host == "" {
		return nil
	}
	mtu := probePathMTU(host)
	if mtu == 0 {
		return []Check{{Group: g, Name: "Path MTU", Level: CheckInfo,
			Detail: "could not probe — the path drops ICMP"}}
	}
	// No negotiated MSS to compare against: nothing here speaks TCP. So the
	// figure is reported with what it implies, and judged only against the
	// obviously-too-small.
	c := Check{Group: g, Name: "Path MTU", Level: CheckOK,
		Detail: fmt.Sprintf("%d to %s", mtu, host)}
	if mtu < 1400 {
		c.Level = CheckWarn
		c.Fix = fmt.Sprintf("the path carries only %d bytes. On a datagram transport nothing "+
			"negotiates this down for you — set mss to %d or lower on both ends, or expect "+
			"large transfers to stall while small ones work", mtu, safeMSS(mtu))
	}
	return []Check{c}
}

// peerHostFor is the address on the far end of a tunnel, from whichever side
// this is.
//
// A client knows where it dials. A server does not know where its client is
// until one connects, and the engine reports that in the metrics snapshot —
// which is the same place the watchdog asks, rather than a second opinion.
func peerHostFor(t core.Tunnel) string {
	if t.Role == "client" {
		return addrHost(t.Addr, "")
	}
	snap, err := metrics.Read(app.ConfigDir, t.Name)
	if err != nil || snap.Peer == "" {
		return ""
	}
	return addrHost(snap.Peer, snap.Peer)
}
