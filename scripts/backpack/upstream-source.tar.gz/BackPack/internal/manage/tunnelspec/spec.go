package tunnelspec

import (
	"fmt"
	"os"
	"strings"

	"github.com/backpack/backpack/internal/app"
	"github.com/backpack/backpack/internal/manage/core"
)

// Spec is the full description of a tunnel used to render a TOML config.
type Spec struct {
	Name      string
	Role      string // "server" (Iran/edge that exposes ports) or "client" (kharej/origin)
	Transport string // tcp, tcpmux, udp, kcp, ws, wss, wsmux, wssmux

	// Preset is the performance profile every tuning field was filled from:
	// balance, turbo or aggressive. Empty means the values were set by hand or
	// by a version that predates presets — either way they are left untouched.
	Preset string

	BindAddr   string   // server: listen address for the tunnel control channel
	RemoteAddr string   // client: address of the server tunnel port
	Token      string   // shared secret
	Ports      []string // server: exposed/forwarded ports

	// LoadBalance spreads data connections across FallbackAddrs instead of
	// only using them when the primary fails. Every address must reach the
	// same server.
	LoadBalance bool

	// HealthFailover scores every address (primary + FallbackAddrs) on a timer
	// and keeps traffic on the healthiest, stepping off an exit as it degrades
	// rather than only when it dies. It overrides LoadBalance.
	HealthFailover bool

	// FallbackAddrs are extra server addresses a client tries, in order, when
	// the primary one cannot be reached — a second IP, a different port, or a
	// CDN edge. This keeps the tunnel up when one address gets filtered.
	FallbackAddrs []string

	// FallbackTransports are extra carriers this tunnel may fall back to when
	// the configured one stops getting through — a different answer to the same
	// problem FallbackAddrs solves, for the case where it is the carrier being
	// filtered rather than the address.
	//
	// Both ends must carry the same list in the same order. They never tell
	// each other where they are; they meet because the server holds each
	// candidate while the client sweeps the list. See internal/tunnel/chain.
	FallbackTransports []string
	// FallbackDwell is how many seconds one candidate is held. 0 = the default.
	FallbackDwell int

	Nodelay        bool
	Heartbeat      int
	KeepAlive      int
	ChannelSize    int
	ConnectionPool int
	AggressivePool bool
	AcceptUDP      bool
	LogLevel       string
	// LogFormat is "" for human-readable output or "json" for machine parsing.
	LogFormat string

	// SMUX / multiplexed transports
	MuxCon          int
	MuxVersion      int
	MuxFrameSize    int
	MuxRecvBuffer   int
	MuxStreamBuffer int

	// KCP transport (reliable ARQ over UDP). Filled from the preset; only
	// written to the config when the transport is kcp.
	KCPMTU          int
	KCPInterval     int // ARQ tick in milliseconds — lower reacts faster, costs CPU
	KCPResend       int // fast-retransmit threshold in duplicate ACKs
	KCPNoDelay      int // 1 enables the low-latency ARQ mode
	KCPNoCongestion int // 1 disables KCP's own congestion window
	KCPSndWnd       int // send window in packets
	KCPRcvWnd       int // receive window in packets
	KCPAckNoDelay   bool
	// FEC: every KCPDataShards packets carry KCPParityShards parity packets, so
	// that many losses are repaired without waiting for a retransmit. 0 = off.
	KCPDataShards   int
	KCPParityShards int

	// Packet-level TCP carrier (pck). All optional: the transport finds its own
	// egress from the route to the peer, and the flag cycle defaults to what
	// ordinary data carries. See config.PckConfig.
	PckInterface  string   // egress device, empty to let the route decide
	PckGatewayMAC string   // next hop's MAC, empty to read the neighbour table
	PckFlags      []string // TCP flag combinations to cycle through, e.g. ["PA"]

	// Throughput / latency tuning
	MSS      int // TCP max segment size (0 = auto)
	SoRcvBuf int // per-socket receive buffer (bytes)
	SoSndBuf int // per-socket send buffer (bytes)

	// ProxyProtocol makes the server prepend a PROXY protocol v2 header to
	// every forwarded connection, so the service behind the tunnel sees the
	// real client IP instead of the tunnel's. Panels need this to enforce
	// per-user device/IP limits. The backend must be configured to expect it.
	ProxyProtocol bool

	// MaxConnections caps simultaneous forwarded connections (0 = unlimited).
	MaxConnections int
	// BandwidthMbps caps total tunnel throughput in Mbit/s (0 = unlimited).
	BandwidthMbps int

	// Sniffer web panel
	Sniffer bool
	WebPort int
	// WebBind is the address that page listens on. Empty means loopback, which
	// is the default because the page has no authentication; see
	// config.ServerConfig.WebBind.
	WebBind string

	// TLS (server, wss/wssmux only)
	TLSCert string
	TLSKey  string
	// ACMEDomain, when set, makes the tunnel obtain a Let's Encrypt certificate
	// for that domain instead of using the generated self-signed one.
	ACMEDomain string
	ACMEEmail  string

	// Edge/CDN IP override (client, websocket transports only)
	EdgeIP string
	// SimpleAuth authorises a wss tunnel by the raw token, for a server behind
	// a TLS-terminating proxy like NGINX. Off by default. See config.SimpleAuth.
	SimpleAuth bool
	// Proxy is the optional socks5:// or http:// URL the client reaches the
	// tunnel server through. Empty means dial it directly.
	Proxy string
	// LocalAddr, Interface and SOMark decide which way out of a multi-homed
	// machine the tunnel leaves by. All optional; empty and zero mean "let the
	// kernel route".
	LocalAddr string
	Interface string
	SOMark    int
	// ZeroCopy hands forwarded traffic to the kernel instead of copying it
	// through this process. Off by default — see config.ZeroCopy.
	ZeroCopy bool
}

// monitorBind is the address the sniffer page is written out with. It is
// emitted rather than left to the engine's default so that the knob is visible
// in the file — an operator who wants the page on the network has to be able to
// find out that they can have it, and a config the CLI rewrites is the only
// place they will look.
func monitorBind(configured string) string {
	if configured == "" {
		return "127.0.0.1"
	}
	return configured
}

// writeTuning emits the throughput/latency knobs shared by server and client.
func (s Spec) writeTuning(p func(string, ...any)) {
	if s.MSS > 0 {
		p("mss = %d\n", s.MSS)
	}
	// The socket buffers size the datagram transports' UDP socket. They are no
	// longer pinned on TCP sockets: doing that stops the kernel auto-tuning the
	// window and caps throughput badly on a fast link. Set so_pin_tcp = true to
	// get the old behaviour back.
	if s.SoRcvBuf > 0 {
		p("so_rcvbuf = %d\n", s.SoRcvBuf)
	}
	if s.SoSndBuf > 0 {
		p("so_sndbuf = %d\n", s.SoSndBuf)
	}
}

// writeKCP emits the KCP knobs. It is a no-op for every other transport, so a
// tunnel that is not on KCP never carries stale KCP settings in its config.
func (s Spec) writeKCP(p func(string, ...any)) {
	if !isKCP(s.Transport) {
		return
	}
	p("kcp_mtu = %d\n", s.KCPMTU)
	p("kcp_interval = %d\n", s.KCPInterval)
	p("kcp_resend = %d\n", s.KCPResend)
	p("kcp_nodelay = %d\n", s.KCPNoDelay)
	p("kcp_nocongestion = %d\n", s.KCPNoCongestion)
	p("kcp_sndwnd = %d\n", s.KCPSndWnd)
	p("kcp_rcvwnd = %d\n", s.KCPRcvWnd)
	p("kcp_acknodelay = %t\n", s.KCPAckNoDelay)
	p("kcp_datashards = %d\n", s.KCPDataShards)
	p("kcp_parityshards = %d\n", s.KCPParityShards)
}

// writePck emits the packet-level TCP carrier's knobs. A no-op for every other
// transport, and it writes nothing it was not given: every one of these is an
// override for a lookup that normally gets it right, so an empty config here is
// the healthy case rather than an unfinished one.
func (s Spec) writePck(p func(string, ...any)) {
	if s.Transport != "pck" {
		return
	}
	if s.PckInterface != "" {
		p("pck_interface = %q\n", s.PckInterface)
	}
	if s.PckGatewayMAC != "" {
		p("pck_gateway_mac = %q\n", s.PckGatewayMAC)
	}
	if len(s.PckFlags) > 0 {
		quoted := make([]string, len(s.PckFlags))
		for i, f := range s.PckFlags {
			quoted[i] = fmt.Sprintf("%q", f)
		}
		p("pck_flags = [%s]\n", strings.Join(quoted, ", "))
	}
}

// isMux reports whether a transport multiplexes over SMUX.

// isKCP reports whether a transport rides on KCP — over UDP (kcp), over ICMP
// echo (xdi), or over hand-built TCP segments (pck). All three are tuned by the
// same kcp_* knobs and the same presets.
//
// It used to say four and name spoof as one of them. Spoof is a direct-tunnel
// carrier and has not been a reverse transport for some time, and the function
// stopped covering it when it stopped being one — the sentence did not.

// supportsProxyProtocol reports whether a transport can prepend the PROXY
// protocol header. The plain websocket and raw UDP transports cannot: one has
// no place to put it in its framing, the other carries datagrams with no
// connection to describe.

// isWS reports whether a transport rides over websocket.

// needsTLS reports whether a transport terminates TLS on the server and
// therefore requires a certificate/key pair.

// validTransport reports whether t is one of the engine's supported transports.

// Render returns the TOML representation of the tunnel.
func (s Spec) Render() string {
	var b strings.Builder
	p := func(format string, a ...any) { fmt.Fprintf(&b, format, a...) }

	b.WriteString("# Generated by backpack — do not edit while the service is running.\n")
	p("# name = \"%s\"\n\n", s.Name)

	if s.Role == "server" {
		b.WriteString("[server]\n")
		p("bind_addr = %q\n", s.BindAddr)
		p("transport = %q\n", s.Transport)
		if s.Preset != "" {
			p("preset = %q\n", s.Preset)
		}
		p("token = %q\n", s.Token)
		p("channel_size = %d\n", s.ChannelSize)
		p("keepalive_period = %d\n", s.KeepAlive)
		p("nodelay = %t\n", s.Nodelay)
		p("heartbeat = %d\n", s.Heartbeat)
		p("log_level = %q\n", s.LogLevel)
		if s.LogFormat != "" {
			p("log_format = %q\n", s.LogFormat)
		}
		s.writeTuning(p)
		s.writeKCP(p)
		s.writePck(p)
		// Written for every transport: a forwarded port carries UDP as well as
		// TCP now, whatever the tunnel is built on, and the value is written
		// out so the file says what the tunnel does rather than relying on a
		// default that has changed once already.
		p("accept_udp = %t\n", s.AcceptUDP)
		if needsTLS(s.Transport) {
			p("tls_cert = %q\n", s.TLSCert)
			p("tls_key = %q\n", s.TLSKey)
			// Emitted only when in use, so a config written before Let's
			// Encrypt existed stays byte-identical after an edit.
			if s.ACMEDomain != "" {
				p("acme_domain = %q\n", s.ACMEDomain)
				if s.ACMEEmail != "" {
					p("acme_email = %q\n", s.ACMEEmail)
				}
			}
			// The server end also has to be told to accept the raw token, or it
			// keeps demanding the bound proof the fronted client can no longer
			// send.
			if s.SimpleAuth {
				p("simple_auth = true\n")
			}
		}
		if isMux(s.Transport) {
			p("mux_con = %d\n", s.MuxCon)
			p("mux_version = %d\n", s.MuxVersion)
			p("mux_framesize = %d\n", s.MuxFrameSize)
			p("mux_recievebuffer = %d\n", s.MuxRecvBuffer)
			p("mux_streambuffer = %d\n", s.MuxStreamBuffer)
		}
		if supportsProxyProtocol(s.Transport) {
			p("proxy_protocol = %t\n", s.ProxyProtocol)
		}
		if s.ZeroCopy {
			p("zero_copy = true\n")
		}
		if s.MaxConnections > 0 {
			p("max_connections = %d\n", s.MaxConnections)
		}
		if s.BandwidthMbps > 0 {
			p("bandwidth_mbps = %d\n", s.BandwidthMbps)
		}
		p("sniffer = %t\n", s.Sniffer)
		if s.WebPort > 0 {
			p("web_port = %d\n", s.WebPort)
			p("web_bind = %q\n", monitorBind(s.WebBind))
		}
		b.WriteString("ports = [\n")
		for _, port := range s.Ports {
			p("    %q,\n", port)
		}
		b.WriteString("]\n")
		s.writeFallbackChain(p, &b)
		return b.String()
	}

	// client
	b.WriteString("[client]\n")
	p("remote_addr = %q\n", s.RemoteAddr)
	if len(s.FallbackAddrs) > 0 {
		b.WriteString("fallback_addrs = [\n")
		for _, a := range s.FallbackAddrs {
			p("    %q,\n", a)
		}
		b.WriteString("]\n")
	}
	p("transport = %q\n", s.Transport)
	s.writeFallbackChain(p, &b)
	if s.Preset != "" {
		p("preset = %q\n", s.Preset)
	}
	p("token = %q\n", s.Token)
	p("connection_pool = %d\n", s.ConnectionPool)
	p("aggressive_pool = %t\n", s.AggressivePool)
	p("keepalive_period = %d\n", s.KeepAlive)
	p("nodelay = %t\n", s.Nodelay)
	if s.LoadBalance {
		p("load_balance = true\n")
	}
	if s.HealthFailover {
		p("health_failover = true\n")
	}
	p("retry_interval = %d\n", 3)
	p("dial_timeout = %d\n", 10)
	p("log_level = %q\n", s.LogLevel)
	if s.LogFormat != "" {
		p("log_format = %q\n", s.LogFormat)
	}
	s.writeTuning(p)
	s.writeKCP(p)
	s.writePck(p)
	if isWS(s.Transport) && s.EdgeIP != "" {
		p("edge_ip = %q\n", s.EdgeIP)
	}
	if needsTLS(s.Transport) && s.SimpleAuth {
		p("simple_auth = true\n")
	}
	if s.Proxy != "" {
		p("proxy = %q\n", s.Proxy)
	}
	if s.LocalAddr != "" {
		p("local_addr = %q\n", s.LocalAddr)
	}
	if s.Interface != "" {
		p("interface = %q\n", s.Interface)
	}
	if s.SOMark != 0 {
		p("so_mark = %d\n", s.SOMark)
	}
	if s.ZeroCopy {
		p("zero_copy = true\n")
	}
	if isMux(s.Transport) {
		p("mux_session = %d\n", s.MuxCon)
		p("mux_version = %d\n", s.MuxVersion)
		p("mux_framesize = %d\n", s.MuxFrameSize)
		p("mux_recievebuffer = %d\n", s.MuxRecvBuffer)
		p("mux_streambuffer = %d\n", s.MuxStreamBuffer)
	}
	p("sniffer = %t\n", s.Sniffer)
	if s.WebPort > 0 {
		p("web_port = %d\n", s.WebPort)
		p("web_bind = %q\n", monitorBind(s.WebBind))
	}
	return b.String()
}

// Save writes the config file, the systemd unit, reloads systemd and starts
// the tunnel. It returns the service name on success.
func (s Spec) Save() (string, error) {
	if err := os.MkdirAll(app.ConfigDir, 0755); err != nil {
		return "", err
	}
	if err := app.WriteFileAtomic(app.ConfigPath(s.Name), []byte(s.Render()), app.TunnelConfigMode); err != nil {
		return "", err
	}
	if err := core.WriteUnit(s.Name); err != nil {
		return "", err
	}
	if err := core.DaemonReload(); err != nil {
		return "", err
	}
	service := app.ServiceName(s.Name)
	if err := core.StartService(service); err != nil {
		return service, err
	}
	return service, nil
}

// writeFallbackChain renders the transport fallback list, and nothing at all
// when there is none — which is the overwhelming majority of tunnels, and the
// reason the key is absent rather than written empty.
func (s Spec) writeFallbackChain(p func(string, ...any), b *strings.Builder) {
	if len(s.FallbackTransports) == 0 {
		return
	}
	b.WriteString("fallback_transports = [\n")
	for _, t := range s.FallbackTransports {
		p("    %q,\n", t)
	}
	b.WriteString("]\n")
	if s.FallbackDwell > 0 {
		p("fallback_dwell = %d\n", s.FallbackDwell)
	}
}
