# Architecture

What BackPack is made of, and which part answers which question. The topic
guides beside this one explain how to do things; this one explains where things
are.

---

## One binary, seven modes

`main.go` dispatches before anything else is decided:

| Invocation | What runs |
|---|---|
| `backpack` | the interactive management menu — `internal/menu` |
| `backpack -c <file>` | **engine mode**: one tunnel, from one config |
| `backpack --webui` | the web panel — `internal/webui` |
| `backpack --monitor` | watchdog, Telegram bot, alerts, history — `internal/monitor` |
| `backpack --proxy` | the built-in SOCKS5/HTTP proxy — `internal/localproxy` |
| `backpack --restart-all` / `--telegram-report` | one-shot jobs, run from cron |
| `backpack node exec -` | the one operation a panel runs on a managed server over SSH |

Everything except engine mode is management. Engine mode is the product.

**One process per tunnel.** Each tunnel is its own systemd unit running
`backpack -c /etc/backpack/<name>.toml`. This is the single most valuable
reliability property in the system and it is free: a panic, a leak or a bad
config affects exactly one tunnel, and systemd restarts exactly that one. Any
proposal to run several tunnels in one process is trading it away.

---

## Three engines, two of them running

`cmd/cmd.go runEngine` chooses, in this order, and the order is load-bearing:

```
        ┌─ [l3] table present?    ──yes──►  internal/tunnel/l3       layer 3
config ─┼─ [direct] table present? ─yes──►  refused: the layer-4 engine was removed in v2.0.0
        └─ [server]/[client]      ────────►  internal/server + internal/client
                                             the reverse tunnel
```

They share **no configuration key and no code**. A file that does not mention
`[l3]` cannot reach the layer-3 engine; one that does never reaches the reverse
tunnel. `L3Config.Enabled()` is one trimmed string, and it is the whole gate.

### The reverse tunnel — `[server]` / `[client]`

The Iran side listens and exposes ports; the kharej side dials out. A control
channel plus a pool of data connections. Twelve transports: `tcp`, `tcpmux`,
`stealth`, `ws`, `wss`, `wsmux`, `wssmux`, `kcp`, `quic`, `udp`, `xdi` and
`pck`. The last two ride the KCP stack over raw and packet sockets.

- `internal/server` / `internal/client` — pick the transport, build its config
- `internal/server/transport` / `internal/client/transport` — the transports
- `internal/utils/handlers` — the forwarding itself: buffered relay, and kernel
  `splice` behind a flag

#### Inside a reverse transport

Each transport is the part that differs — how its tunnel connections are
accepted or dialled, and how a user's connection rides one. What every one of
them has to get the same is shared, on each side:

| Module | Side | What it owns |
|---|---|---|
| `lifecycle.go` | both | the **generation**: one control channel and everything serving it, on one context; ending it and starting the next, one restart at a time |
| `forward.go` (`portForwarder`) | server | the forwarded ports: bind, admit under the limits, queue, release what is still queued when the generation ends |
| `controlloop.go` (`controlLoop`) | both | the control channel's loop: heartbeat, requests for pool connections, the goodbye, bound to the channel its generation started with |
| `internal/controlwire` | both | how a signal travels — one byte on a stream, one binary message on a websocket — and the write bound both ends share |
| `pairing.go`, `pairloop.go` | server | matching a queued user with a tunnel connection |
| `poolmaintain.go` | client | sizing the pool of tunnel connections |

A transport supplies adapters to these — its socket options, what a queued user
asks for, how long its goodbye needs to leave — and nothing else. A fix to one
of them is a fix to all twelve transports; the reason for the split, and what it
replaced, is [ADR 0001](adr/0001-reverse-transport-generations.md). A generation
outlives the kharej it serves: a re-dialing kharej is seated in place and no
port is re-bound — [ADR 0005](adr/0005-a-generation-outlives-its-clients.md).

### The old direct tunnel — `[direct]` (removed)

The layer-4 stream tunnel, Iran dialling out, was removed in v2.0.0. A file with
a `[direct]` table is still recognised (`config/legacydirect.go`) and refused by
name; it can be listed and deleted but not run. The direct direction is now the
layer-3 tunnel below. See [Direct tunnel](direct-tunnel.md).

### The layer-3 tunnel — `[l3]`

An interface on each host carrying whole IP packets. Noise NNpsk0, explicit
nonces, a 2048-bit replay window (RFC 4303, as WireGuard uses). Four carriers
underneath, all raw sockets and Linux only: `xdi`, `sni`, `spoof` — and `pck`,
which since v2.0.0 is not one of them: it is `internal/tunnel/paqet`, a port of
[paqet](https://github.com/hanselime/paqet) (KCP and smux over TCP segments built
and captured with libpcap) that forwards ports and has no TUN. See
[Direct PCK](direct-pck.md). The `carrier` key is required; `udp` and `quic` were
removed in v2.0.0.
`internal/tunnel/l3`.

The same table also runs **kernel GRE** (`carrier = "gre"` or `"ip6gre"`): the
engine creates a Linux GRE link with ip(8) instead of a TUN device and a session,
holds it while it runs and pings the other end across it for liveness, and the
same forwarder serves `ports` over it. Unencrypted by design.
`internal/tunnel/l3/kernelgre.go`.

A reliable carrier is deliberately not an option here — stacking retransmission
under a reliable tunnel is actively harmful, not merely wasteful. The package
doc explains why.

---

## The seam between the engines and everything watching them

This is the piece worth knowing before changing anything.

```
  engine process                    every other process
  ──────────────                    ───────────────────
  internal/metrics  ──writes──►  /etc/backpack/<name>.metrics.json
                                        │
                                        ├──►  the panel
                                        ├──►  the Telegram bot
                                        ├──►  the CLI
                                        └──►  the watchdog
```

Nothing reaches into a running tunnel. The engine writes a JSON snapshot every
thirty seconds — traffic, peer, pool state, whether the control channel is up,
and what the process is holding (goroutines, descriptors, heap) — and every
other process reads that file.

It is why the watchdog asks the engine rather than the kernel: a socket outlives
the tunnel it belongs to by a long way, and every failure the watchdog used to
miss looked healthy in the socket table.

---

## Management

| Package | Responsibility |
|---|---|
| `internal/manage` | the real work, and the seam the panel and the CLI both call: wizards, editing, the panel's API, update, migration (12,600 lines). Layered below it: `manage/tunnelspec` (a tunnel's configuration: render, load, apply with revert, presets, history), `manage/health` (tunnel health, watchdog, Health Check), `manage/host` (this machine's addresses, ports, certificates), `manage/backup`, and `manage/core` + `manage/spec` at the bottom (tunnel listing, systemd, the transport and address vocabulary). Each re-exports through `internal/manage`, so callers see one package |
| `internal/menu` | the interactive TUI, over `internal/tui`; its screens are tested through a scripted input |
| `internal/webui` | the panel: a Go mux plus a vanilla-JS SPA under `panel/`, served beneath a random secret base path. Also currently owns the fleet |
| `internal/telegram` | bot, alerts, scheduled reports. Has a read-only admin tier |
| `internal/node` | the fleet: JSON over the managed server's own SSH, with a closed list of operations |
| `internal/monitor` | the always-on service: watchdog, bot, alerts, history sampler, auto-backup — each in its own supervised goroutine |

`internal/manage` is the seam. The panel and the CLI are two callers of the same
functions, which is why a setting can be changed wherever it can be chosen.

### The fleet

The panel dials **out** over the managed server's own SSH. The far side needs no
agent, no daemon and no state — `backpack node exec -` performs one
operation from a closed list and prints the answer. The list is the security
boundary: there is no operation that runs a command, reads a path or installs a
binary.

---

## Update and recovery

```
latest tag ──► signature over SHA256SUMS ──► checksum of the archive
                       │                              │
                    refuse                         refuse
                       ▼                              ▼
              snapshot ──► install ──► migrate ──► restart ──► health check
                                                                    │
                                                              failed? roll back
```

`internal/manage/update.go`, with `migrate.go` as the mechanism that forces a
correction onto a server an older version set up — idempotent, no marker file,
run on every update.

---

## Support packages

`internal/utils/network` (88 files) is where the unusual work lives: Noise,
nonce pools, KCP, uTLS, the spoof and pck carriers, ICMP, outbound routing,
endpoints, TLS config.

`internal/tunnel/portmap` parses the forwarded-port syntax all engines share.
`internal/tunnel/limits` and `internal/server/transport/limits.go` are the
per-tunnel caps. `internal/tunnel/mssclamp` is the MSS clamp.
`internal/metrics`, `internal/tunhist`, `internal/alerthist` are the three
stores. `internal/sysstat`, `internal/geo`, `internal/optimize`,
`internal/schedule`, `internal/debugserver` are the small ones.

---

## Where to start reading

- **A tunnel does not come up** → `backpack check -c <file>` first (the engine's
  own load-time checks), then `cmd/cmd.go`, then the transport under
  `internal/server/transport`
- **A tunnel drops or restarts** → `lifecycle.go` and `controlloop.go` on each
  side, before any one transport
- **Something about the panel** → `internal/webui/server.go` for the routes,
  `panel/js/api.js` for every call the page makes
- **Something about setup or editing** → `internal/manage`
- **Layer-3** → `internal/tunnel/l3/doc.go`, then `session.go` and `tunnel*.go` (state, pumps, receive, handshake)

The package comments carry the reasoning — what was tried, what it cost, why the
obvious alternative is wrong. They are the best documentation in the project and
they are worth reading before changing the code they sit on.

---

<div dir="rtl">

## خلاصهٔ فارسی

این صفحه می‌گوید Backpack از چه ساخته شده و کدام بخش به کدام سؤال جواب می‌دهد.
بقیهٔ راهنماها می‌گویند «چطور کاری را بکنی»؛ این یکی می‌گوید «چیزها کجایند».

**یک باینری، هفت حالت.** `main.go` قبل از هر چیز دیگری تصمیم می‌گیرد: `backpack`
منوی مدیریت است؛ `backpack -c <file>` **حالت موتور** است یعنی یک تونل از یک
کانفیگ؛ `--webui` پنل وب؛ `--monitor` نگهبان و ربات تلگرام و هشدارها و تاریخچه؛
`--proxy` پراکسی داخلی SOCKS5/HTTP؛ `--restart-all` و `--telegram-report` کارهای
یک‌باره‌ای که از cron اجرا می‌شوند؛ و `backpack node exec -` تنها عملیاتی
که پنل روی یک سرور مدیریت‌شده از طریق SSH اجرا می‌کند. **هر چیزی جز حالت موتور،
مدیریت است. حالت موتور، خودِ محصول است.** هر تونل یک سرویس systemd جداگانه و یک
پروسهٔ جداگانه دارد.

**سه موتور،** و `cmd/cmd.go runEngine` به همین ترتیب انتخاب می‌کند: اگر جدول
`[l3]` باشد → موتور لایه‌۳؛ وگرنه اگر `[direct]` باشد → رد می‌شود (موتور لایه‌۴ در
v2.0.0 حذف شد)؛ وگرنه `[server]`/`[client]` → تونل معکوس. **هیچ کلید کانفیگ و هیچ کدی بین‌شان
مشترک نیست.** فایلی که `[l3]` ندارد اصلاً به موتور لایه‌۳ نمی‌رسد، و فایلی که
دارد هیچ‌وقت به موتور معکوس نمی‌رسد.

**درزِ بین موتورها و هر چیزی که تماشایشان می‌کند** — مهم‌ترین چیزی که قبل از
تغییر دادن هر چیزی باید بدانی: **هیچ‌چیز دستش را داخل یک تونل در حال اجرا
نمی‌کند.** موتور هر سی ثانیه یک snapshot از جنس JSON می‌نویسد — ترافیک، peer،
وضعیت استخر، بالابودن کانال کنترل، و آنچه پروسه نگه داشته (goroutine، descriptor،
heap) — و هر پروسهٔ دیگری همان فایل را می‌خواند: پنل، ربات تلگرام، CLI و نگهبان.
برای همین است که نگهبان از خودِ موتور می‌پرسد نه از کرنل: یک سوکت خیلی بیشتر از
تونلی که به آن تعلق دارد زنده می‌ماند، و هر خرابی‌ای که نگهبان قبلاً از دست
می‌داد در جدول سوکت‌ها سالم به‌نظر می‌رسید.

**داخل یک ترنسپورتِ معکوس** فقط چیزی است که واقعاً فرق می‌کند. بقیه — چرخهٔ
**نسل‌ها** (`lifecycle.go`: یک کانال کنترل و هر چیزی که به آن خدمت می‌کند، روی یک
context)، پورت‌های فوروارد (`forward.go`)، حلقهٔ کانال کنترل (`controlloop.go`) و
شکلِ سیگنال‌ها روی سیم (`internal/controlwire`) — یک بار نوشته شده و هر دوازده
ترنسپورت از همان استفاده می‌کنند. دلیلش در [ADR 0001](adr/0001-reverse-transport-generations.md) است.

**از کجا شروع به خواندن کنی:** تونل بالا نمی‌آید → اول `backpack check -c <file>`، بعد `cmd/cmd.go` و بعد ترنسپورت
زیر `internal/server/transport`. چیزی دربارهٔ پنل → `internal/webui/server.go`
برای مسیرها و `panel/js/api.js` برای هر فراخوانی صفحه. چیزی دربارهٔ راه‌اندازی یا
ویرایش → `internal/manage`. لایه‌۳ → `internal/tunnel/l3/doc.go` و بعد
`session.go` و `tunnel.go`.

**کامنت‌های سر پکیج‌ها استدلال را دارند** — چه چیزی امتحان شده، چه هزینه‌ای داشته،
و چرا جایگزینِ بدیهی غلط است. بهترین مستندات این پروژه همان‌ها هستند و ارزشش را
دارند که قبل از تغییرِ کدی که رویشان نشسته خوانده شوند.

</div>

---
[← Back to the docs index](README.md)

---

*Last verified against Backpack v2.0.0.*
